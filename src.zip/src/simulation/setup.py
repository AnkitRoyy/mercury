from setuptools import find_packages, setup
import os
from glob import glob
package_name = 'simulation'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),

        ('share/' + package_name, ['package.xml']),

        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')),

        (os.path.join('share', package_name, 'worlds'),
            glob('worlds/*.sdf')),

        (os.path.join('share', package_name, 'models/ugvc_track'),
            glob('models/ugvc_track/model*')),

        (os.path.join('share', package_name, 'models/ugvc_track/meshes'),
            glob('models/ugvc_track/meshes/*')),
        (os.path.join('share', package_name, 'models/images'),
            glob('models/images/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='soap',
    maintainer_email='dakshpanchal08@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        ],
    },
)
